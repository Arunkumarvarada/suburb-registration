package com.searce.suburbregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuburbRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
