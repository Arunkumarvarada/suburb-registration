INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Bangalore',10101)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Mangalore',10102)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Udapi',10103)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Bellary',10104)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Chikkballapur',10105)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Shivmogga',10106)
INSERT INTO suburbdetails (suburbname,zipcode) VALUES ('Hasan',10107)

