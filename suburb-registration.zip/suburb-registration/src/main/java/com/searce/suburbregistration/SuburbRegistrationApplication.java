package com.searce.suburbregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuburbRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuburbRegistrationApplication.class, args);
	}

}
