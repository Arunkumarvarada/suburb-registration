package com.searce.suburbregistration.controller;

import com.searce.suburbregistration.dao.SuburbRegistrationRepository;
import com.searce.suburbregistration.entities.SuburbDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/suburbdetails")
public class SuburbRegistrationController {

    @Autowired
    SuburbRegistrationRepository suburbRegistrationRepository;

    @PostMapping
    public ResponseEntity<SuburbDetails> createTutorial(@RequestBody SuburbDetails requestDetails) {
        try {
            SuburbDetails suburbDetails = suburbRegistrationRepository
                    .save(new SuburbDetails(requestDetails.getSuburbId(), requestDetails.getSuburbName(), requestDetails.getZipcode()));
            return new ResponseEntity<>(suburbDetails, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    Page<SuburbDetails> getSuburbDetails(
            @RequestParam Optional<Integer> page,
            @RequestParam Optional<Integer> range,
            @RequestParam Optional<String> sortBy,
    ) {
        return suburbRegistrationRepository.findAll(
                PageRequest.of(
                        page.orElse(0),
                        range.orElse(20),
                        Sort.Direction.ASC, sortBy.orElse("suburbName")
                )
        );
    }
}
