package com.searce.suburbregistration.dao;

import com.searce.suburbregistration.entities.SuburbDetails;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SuburbRegistrationRepository extends JpaRepository<SuburbDetails, Long> {
  
    void delete(SuburbDetails deleted);
  
    Page<SuburbDetails> findAll(Pageable pageRequest);
  
    Optional<SuburbDetails> findOne(Long id);
  
    void flush();

    SuburbDetails save(SuburbDetails persisted);
}