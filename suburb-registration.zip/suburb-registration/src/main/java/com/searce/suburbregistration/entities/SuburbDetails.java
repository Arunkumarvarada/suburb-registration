package com.searce.suburbregistration.entities;

import javax.persistence.*;

@Entity
@Table(name = "suburbdetails")
public class SuburbDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "suburbid")
    private Long suburbId;

    @Column(name = "suburbname")
    private String suburbName;

    @Column(name = "zipcode")
    private String zipcode;


    public SuburbDetails() {

    }

    public SuburbDetails(Long suburbId, String suburbName, String zipcode) {
        this.suburbId = suburbId;
        this.suburbName = suburbName;
        this.zipcode = zipcode;
    }

    public Long getSuburbId() {
        return suburbId;
    }

    public void setSuburbId(Long suburbId) {
        this.suburbId = suburbId;
    }

    public String getSuburbName() {
        return suburbName;
    }

    public void setSuburbName(String suburbName) {
        this.suburbName = suburbName;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
}
